# Ownership Page — Installation

This patch adds the `/ownership` deep-dive page to the artists app.

## What's new

**Shared UI (packages/ui/src/)**
- `components/SubPageShell.tsx` — reusable wrapper every sub-page will use (nav + scroll progress + power band + footer)
- `index.ts` — updated to export SubPageShell

**Artists app (apps/artists/)**
- `app/site-config.ts` — shared nav/footer config used by sub-pages
- `app/ownership/page.tsx` — the page itself
- `app/ownership/sections/` — 8 section components:
  - `OwnershipHero.tsx` — signed-PDF hero with angled contract mockup
  - `OneLineProof.tsx` — the quiet centered claim
  - `ComparisonTable.tsx` — Unis vs 5 competitors table
  - `TheAgreement.tsx` — contract excerpt with highlighted clauses
  - `NonExclusivity.tsx` — "you don't have to leave anywhere else" section
  - `TheMoneyQuestion.tsx` — how Unis affords the 60/85/free model
  - `OwnershipFAQ.tsx` — 6-question accordion
  - `OwnershipFinalCTA.tsx` — closing CTA with agreement download
- `public/sample-agreement.pdf` — the generated 3-page sample agreement

## How to install

Unzip this patch over your existing `unis-marketing` folder. All paths match;
no existing files are overwritten except `packages/ui/src/index.ts` (which just
adds one export line — safe to replace).

```bash
# From your unis-marketing folder:
unzip -o ownership-patch.zip

# No re-install needed — no new dependencies.
# Just restart the artists dev server:
pnpm dev:artists
```

Then visit **http://localhost:3001/ownership**.

## Test the download

The primary and secondary CTAs point at `/sample-agreement.pdf`. Click one
to verify the PDF opens in a new tab and looks clean.

## What to check

1. Hero renders with the angled contract mockup on the right
2. "They all say 'you keep your music.' We're the only ones who put it in writing." quiet moment
3. Comparison table scrolls horizontally on narrow screens
4. The agreement section's three highlighted clauses
5. Non-exclusivity diagram shows Spotify/Apple/Tidal/YouTube + Unis
6. "The money question" 3-card grid resolves into the final one-liner
7. FAQ accordion: click to expand/collapse, one open at a time
8. Final CTA, both buttons work, email link opens mail client
9. Back at the homepage, the footer's "Ownership agreement" link goes to /ownership
10. The nav's "Ownership" link still scrolls to the pillar on the homepage,
    BUT on any sub-page (like /ownership itself) it routes back to /ownership
