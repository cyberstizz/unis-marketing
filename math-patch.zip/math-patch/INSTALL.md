# The Math Page — Install

This patch adds the `/math` deep-dive page to your artist site — the final
Priority 1 page. Completes the four-page artist site.

## What's in the zip

One folder: `math/`. Drops into your artists app at `apps/artists/app/math`.

```
math/
├── page.tsx                               ← makes /math work
├── data.ts                                ← splits, assumptions, commitments
└── sections/
    ├── MathHero.tsx                       ← "every dollar. every split. public."
    ├── OpenMathMoment.tsx                 ← quiet one-line claim
    ├── DollarFlowSimulator.tsx            ← ★ interactive dollar-flow demo
    ├── EverySplit.tsx                     ← consolidated all-splits table
    ├── AssumptionsLedger.tsx              ← every assumption, documented
    ├── TransparencyCommitments.tsx        ← quarterly publishing commitments
    ├── PlatformAvailability.tsx           ← iOS · Android · Web
    └── MathFinalCTA.tsx                   ← bookmark this page
```

No dependency changes. No overwrites. No shared UI edits. Same install pattern
as the last two patches.

## How to install

**From your project root:**

```bash
cd ~/code/unis-marketing
unzip ~/Downloads/math-patch.zip
mv math-patch/math apps/artists/app/math
rm -rf math-patch
ls apps/artists/app/math
```

The last command should show: `data.ts  page.tsx  sections`.

## Verify in the browser

If your artists dev server is running, the new route appears automatically.
If anything seems off, hit Ctrl+C on the terminal running `pnpm dev:artists`
and run it again.

Visit **http://localhost:3001/math**.

## What to test

1. **Hero** — "Every dollar. Every split. Every assumption. Public." + the mini SVG flow preview on the right with looping animated particles.

2. **The Dollar Flow Simulator (THE BIG ONE):**
   - Default tab: Display ad · $1.00.
   - Watch particles emit from the $1 source and flow along dashed paths to five payee buckets (Unis, Supporter, L1, L2, L3).
   - The payee bucket amounts count up from $0 to their correct split as particles arrive — smooth tween, not jump.
   - Click **Audio ad** tab — note the amber "Soon" pill. Particles now include MLC as a sixth destination (15.3% of gross off the top), and the net splits redistribute across artist/unis/referrals.
   - Click **Paid subscription** tab — $5.99 at the source, two-way split (artist 50% / Unis 50%).
   - Click **Direct sale** tab — $1.99 source, 85/15 split.
   - Click **Replay** — particles re-emit, buckets reset and count up again.
   - Click **Share** — URL `#flow=display` (or whichever source) copies to clipboard.
   - Visit `http://localhost:3001/math#flow=audio` — page loads with the Audio ad tab pre-selected.

3. **Every Split table** — consolidated reference. 7 payees × 4 sources. Payees that aren't paid by a given source show `—`. Notice the footer line cross-referencing `/ownership` and `/revenue` as clickable links.

4. **Assumptions Ledger** — 8 documented assumptions: ad revenue per user, MLC rate, paid tier price, direct sale floor, payout threshold, payout timing, referral depth, voting mechanics. Each with methodology, source, reviewed date, and a "Revises with data" or "Fixed" tag.

5. **Transparency Commitments** — two columns: "Publishing now" (quarterly awards count, plus "Spotify publishes once a year. Unis commits to four.") and "Once audio ads launch" (per-jurisdiction ad revenue, payouts by stream, conversion rates, referral depth, platform growth).

6. **Platform Availability** — three cards for iOS, Android, Web. Each links to the respective store or the web app.

7. **Final CTA** — "Bookmark this page. The math won't change. The data will." — with three action buttons.

## Things worth knowing

- **The Dollar Flow Simulator uses SVG `<animateMotion>`** for the particle animation. It's declarative, very performant, and works on every modern browser without JavaScript animation overhead. Each tab switch triggers a fresh animation run via a `runId` key bump.
- **The MLC calculation on audio ads** is represented as absolute-of-gross: MLC first takes 15.3%, then the remaining 84.7% splits per 60/23/10/5/2. The simulator shows all six destinations for audio (vs five for display) because MLC becomes a real payee once audio is live.
- **The assumptions ledger has an Internet Archive link** in the footer, pointing at the Wayback Machine's snapshots of this exact page. That's the "historical version" hook — old versions of the ledger remain accessible via the public web even if we update the page.
- **The placeholder App Store / Play Store URLs** in `data.ts` (`id0000000000` and `com.unis.music`) are stubs. Swap them for real URLs once the apps are published — file is `math/data.ts`, at the bottom.

## That's all four Priority 1 pages

Artists site structure now:

| Page | Status |
|---|---|
| `/` Homepage | ✅ |
| `/ownership` | ✅ |
| `/revenue` | ✅ |
| `/jurisdictions` | ✅ |
| `/math` | ✅ (this patch) |

Optional Priority 2–3 pages remaining (About, Careers, Press, Support, Contact,
Privacy, Terms, blog posts). These are smaller, less strategy-heavy, and can
be knocked out faster when you're ready.
